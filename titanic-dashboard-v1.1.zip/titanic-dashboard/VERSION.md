# Titanic Dashboard - Version History

## v1.1 - Poetry Support & Python Version Fix
**Release Date:** 2025-02-08

### Changes
- ✅ Added Poetry support with proper pyproject.toml
- ✅ Fixed Python version requirement (changed from >=3.8 to ^3.9)
- ✅ Updated setup.sh to auto-detect Poetry, UV, or pip
- ✅ Updated all documentation with Poetry instructions
- ✅ Now supports three package managers: Poetry, UV, and pip

### Package Manager Support
- **Poetry** - Best for dependency management (recommended)
- **UV** - Fastest installation
- **pip** - Traditional Python package manager

### Fixed Issues
- Resolved Poetry dependency conflict with pandas requiring Python >=3.9
- Setup script now detects and uses available package manager

---

## v1.0 - Initial Complete Release
**Release Date:** 2025-02-08

### Features
- ✅ Flask backend with REST API (7 endpoints)
- ✅ WebSocket support for real-time metrics
- ✅ Complete Angular frontend with TypeScript
- ✅ Sample Titanic dataset with Pandas
- ✅ Responsive dashboard UI
- ✅ UV and pip support for package management
- ✅ Complete Angular CLI workspace configuration
- ✅ Test scripts for API and WebSocket

### Fixed Issues
- Fixed WebSocket broadcast parameter error
- Added complete Angular configuration files
- Added UV package manager support

### Files Included
- Backend: Flask app, requirements, pyproject.toml, tests
- Frontend: Complete Angular project structure
- Documentation: README, QUICKSTART, TECHNICAL_OVERVIEW
- Setup: Automated setup.sh script

### Known Issues
- Node.js v25 (odd version) warning - recommend v20 LTS
- Sample data only - replace with actual Titanic dataset if needed

---

## Future Versions

### v2.0 (Planned)
- Database integration
- Authentication
- Advanced visualizations
