# Titanic Dashboard - Version History

## v1.4 - Backend Debugging Tools
**Release Date:** 2025-02-08

### Changes
- ✅ Added `test_minimal.py` - Minimal Flask test server
- ✅ Added `debug_backend.sh` - Comprehensive backend diagnostics
- ✅ Added `BACKEND_DEBUG.md` - Detailed troubleshooting for backend issues
- ✅ Enhanced debugging documentation

### New Files
- `backend/test_minimal.py` - Simple Flask server to test basic functionality
- `backend/debug_backend.sh` - Automated backend diagnostic script
- `BACKEND_DEBUG.md` - Step-by-step guide for backend connectivity issues

### Debugging Features
- Check Python version and virtual environment
- Test all dependency imports
- Check port availability
- Test minimal Flask server
- Syntax check for app.py
- Detailed error messages and solutions

### Use Cases
- Backend not starting
- API endpoints not reachable
- Port conflicts
- Dependency issues
- Connection problems

---

## v1.3 - Port Change to 6000
**Release Date:** 2025-02-08

### Changes
- ✅ Changed backend port from 5000 to 6000
- ✅ Updated all configuration files to use port 6000
- ✅ Updated all documentation to reference port 6000
- ✅ Updated test scripts (test_api.py, test_websocket.py)
- ✅ Updated diagnostic script (diagnose.sh)
- ✅ Updated frontend service to connect to port 6000

### Files Updated
- `backend/app.py` - Server now runs on port 6000
- `frontend/src/app/services/titanic.service.ts` - API and WebSocket URLs
- `backend/test_api.py` - Test script base URL
- `backend/test_websocket.py` - WebSocket connection URL
- `diagnose.sh` - Diagnostic checks
- All documentation files (README, QUICKSTART, TROUBLESHOOTING, etc.)

### Why Port 6000?
- Avoids conflicts with other services running on port 5000
- Common alternative port for development servers

---

## v1.2 - Enhanced Debugging & Error Handling
**Release Date:** 2025-02-08

### Changes
- ✅ Added comprehensive TROUBLESHOOTING.md guide
- ✅ Added diagnose.sh script for automatic diagnostics
- ✅ Enhanced WebSocket error handling with better logging
- ✅ Added reconnection logic for WebSocket connections
- ✅ Improved console logging with emojis for easier debugging

### New Files
- `TROUBLESHOOTING.md` - Complete troubleshooting guide
- `diagnose.sh` - Automated diagnostic script

### Improvements
- Better error messages in browser console
- WebSocket auto-reconnection with 5 attempts
- Clearer indication when backend is not running
- Step-by-step debugging instructions

### Common Issues Addressed
- "Failed to load statistics" error
- Backend connection issues
- CORS configuration
- Port conflicts
- Missing dependencies

---

## v1.1 - Poetry Support & Python Version Fix
**Release Date:** 2025-02-08

### Changes
- ✅ Added Poetry support with proper pyproject.toml
- ✅ Fixed Python version requirement (changed from >=3.8 to ^3.9)
- ✅ Updated setup.sh to auto-detect Poetry, UV, or pip
- ✅ Updated all documentation with Poetry instructions
- ✅ Now supports three package managers: Poetry, UV, and pip

### Package Manager Support
- **Poetry** - Best for dependency management (recommended)
- **UV** - Fastest installation
- **pip** - Traditional Python package manager

### Fixed Issues
- Resolved Poetry dependency conflict with pandas requiring Python >=3.9
- Setup script now detects and uses available package manager

---

## v1.0 - Initial Complete Release
**Release Date:** 2025-02-08

### Features
- ✅ Flask backend with REST API (7 endpoints)
- ✅ WebSocket support for real-time metrics
- ✅ Complete Angular frontend with TypeScript
- ✅ Sample Titanic dataset with Pandas
- ✅ Responsive dashboard UI
- ✅ UV and pip support for package management
- ✅ Complete Angular CLI workspace configuration
- ✅ Test scripts for API and WebSocket

### Fixed Issues
- Fixed WebSocket broadcast parameter error
- Added complete Angular configuration files
- Added UV package manager support

### Files Included
- Backend: Flask app, requirements, pyproject.toml, tests
- Frontend: Complete Angular project structure
- Documentation: README, QUICKSTART, TECHNICAL_OVERVIEW
- Setup: Automated setup.sh script

### Known Issues
- Node.js v25 (odd version) warning - recommend v20 LTS
- Sample data only - replace with actual Titanic dataset if needed

---

## Future Versions

### v2.0 (Planned)
- Database integration
- Authentication
- Advanced visualizations
