import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-dashboard></app-dashboard>',
  styles: []
})
export class AppComponent {
  title = 'Titanic Dashboard';
}
