#!/bin/bash

echo "=================================="
echo "Titanic Dashboard Setup Script"
echo "=================================="
echo ""

# Backend Setup
echo "Setting up Backend..."
cd backend

echo "Creating virtual environment..."
python3 -m venv venv

echo "Activating virtual environment..."
source venv/bin/activate

echo "Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "Backend setup complete!"
echo ""
echo "To start the backend server:"
echo "  cd backend"
echo "  source venv/bin/activate"
echo "  python app.py"
echo ""

# Frontend Setup
cd ../frontend

echo "Setting up Frontend..."
echo "Installing npm dependencies..."
npm install

echo ""
echo "Frontend setup complete!"
echo ""
echo "To start the frontend server:"
echo "  cd frontend"
echo "  npm start"
echo ""

echo "=================================="
echo "Setup Complete!"
echo "=================================="
echo ""
echo "Quick Start:"
echo "1. Terminal 1: cd backend && source venv/bin/activate && python app.py"
echo "2. Terminal 2: cd frontend && npm start"
echo "3. Open browser to http://localhost:4200"
echo ""
